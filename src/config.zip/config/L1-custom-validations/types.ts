export type validationOutput = {
	valid: boolean;
	code: number;
	description?: string;
}[];
